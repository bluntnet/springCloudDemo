package com.forezp.service;


import com.forezp.domain.User;

public interface UserService {

	void create(User user);

}

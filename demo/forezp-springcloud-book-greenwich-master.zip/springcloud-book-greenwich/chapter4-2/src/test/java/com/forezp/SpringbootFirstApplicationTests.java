package com.forezp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @RunWith(SpringRunner.class) 和 @SpringBootTest 即可开启spring boot测试
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootFirstApplicationTests {

	@Test
	public void contextLoads() {
	}

}

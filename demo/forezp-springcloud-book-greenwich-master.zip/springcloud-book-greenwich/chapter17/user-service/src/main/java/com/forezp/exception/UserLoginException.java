package com.forezp.exception;

/**
 * Created by fangzhipeng on 2017/6/1.
 */
public class UserLoginException extends RuntimeException{

    public UserLoginException(String message) {
        super(message);
    }

}
